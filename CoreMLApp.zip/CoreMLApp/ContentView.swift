//
//  ContentView.swift
//  CoreMLApp
//

import SwiftUI

struct ContentView: View {
    @State private var viewModel = CameraViewModel()
    
    @State private var showAlert = false
    @State private var detectedRouterName = ""
    
    var body: some View {
        ZStack {
            // live camera
            FrameView(image: viewModel.frame)
                .ignoresSafeArea()
            
            // Overlay for Bounding Boxes
            GeometryReader { geometry in
                ForEach(viewModel.detections) { det in
                    let rect = det.boundingBox
                    let boxWidth  = rect.width  * geometry.size.width
                    let boxHeight = rect.height * geometry.size.height
                    let boxX = rect.minX * geometry.size.width
                    let boxY = (1 - rect.minY - rect.height) * geometry.size.height
                    
                    ZStack(alignment: .topLeading) {
                        Rectangle()
                            .stroke(Color.red, lineWidth: 2)
                            .frame(width: boxWidth, height: boxHeight)
                        
                        Text(String(format: "%@ (%.0f%%)", det.label, det.confidence * 100))
                            .font(.caption).bold()
                            .foregroundColor(.white)
                            .padding(4)
                            .background(Color.green.opacity(0.7))
                    }
                    .position(x: boxX + boxWidth/2, y: boxY + boxHeight/2)
                }
            }
        }
        .onAppear {
            Task {
                await viewModel.startCamera()
            }
        }
        .onChange(of: viewModel.lastDetectedRouter) { _, newValue in
            if let name = newValue {
                detectedRouterName = name
                showAlert = true
            }
        }
    }
}

